const db = require('../db');

const createTable = () => {
    const sql = `
        CREATE TABLE IF NOT EXISTS Patient (
            PatientID INTEGER PRIMARY KEY AUTOINCREMENT,
            FirstName VARCHAR(50),
            LastName VARCHAR(50),
            DateOfBirth DATE,
            Gender VARCHAR(10),
            Address VARCHAR(100),
            PhoneNumber VARCHAR(15),
            Email VARCHAR(50)
        )`;
    return db.run(sql);
};

const create = (patient, callback) => {
    return db.run(
        'INSERT INTO Patient (FirstName, LastName, DateOfBirth, Gender, Address, PhoneNumber, Email) VALUES (?,?,?,?,?,?,?)',
        [patient.FirstName, patient.LastName, patient.DateOfBirth, patient.Gender, patient.Address, patient.PhoneNumber, patient.Email],
        callback
    );
};

// 추가적인 CRUD 함수 구현 (findAll, findById, update, delete 등)

module.exports = {
    createTable,
    create,
    // 다른 함수들
};

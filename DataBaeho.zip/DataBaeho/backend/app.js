const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const db = require('./db'); // DB 연결 설정 파일 불러오기
const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '../frontend')));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// 라우트 설정
const patientRoutes = require('./routes/patient');
const doctorRoutes = require('./routes/doctor');
const appointmentRoutes = require('./routes/appointment');
const scheduleRoutes = require('./routes/schedule');
const medicationRoutes = require('./routes/medication');

app.use('/patients', patientRoutes);
app.use('/doctors', doctorRoutes);
app.use('/appointments', appointmentRoutes);
app.use('/schedules', scheduleRoutes);
app.use('/medications', medicationRoutes);

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}/`);
});

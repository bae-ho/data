const express = require('express');
const router = express.Router();
const patientController = require('../controllers/patientController');

router.post('/', patientController.create); // 환자 정보 추가 라우트
router.get('/', patientController.findAll);
router.get('/:id', patientController.findById);
router.put('/:id', patientController.update);
router.delete('/:id', patientController.delete);

module.exports = router;

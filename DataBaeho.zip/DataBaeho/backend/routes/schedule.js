const express = require('express');
const router = express.Router();
const scheduleController = require('../controllers/scheduleController');

router.post('/', scheduleController.create); // 일정 정보 추가 라우트
router.get('/', scheduleController.findAll);
router.get('/:id', scheduleController.findById);
router.put('/:id', scheduleController.update);
router.delete('/:id', scheduleController.delete);

module.exports = router;

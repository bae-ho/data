const express = require('express');
const router = express.Router();
const doctorController = require('../controllers/doctorController');

router.post('/', doctorController.create); // 의사 정보 추가 라우트
router.get('/', doctorController.findAll);
router.get('/:id', doctorController.findById);
router.put('/:id', doctorController.update);
router.delete('/:id', doctorController.delete);

module.exports = router;

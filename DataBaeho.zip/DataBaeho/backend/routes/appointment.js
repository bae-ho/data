const express = require('express');
const router = express.Router();
const appointmentController = require('../controllers/appointmentController');

router.post('/', appointmentController.create); // 예약 정보 추가 라우트
router.get('/', appointmentController.findAll);
router.get('/:id', appointmentController.findById);
router.put('/:id', appointmentController.update);
router.delete('/:id', appointmentController.delete);

module.exports = router;

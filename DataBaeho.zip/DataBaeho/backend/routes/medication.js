const express = require('express');
const router = express.Router();
const medicationController = require('../controllers/medicationController');

router.post('/', medicationController.create); // 약 정보 추가 라우트
router.get('/', medicationController.findAll);
router.get('/:id', medicationController.findById);
router.put('/:id', medicationController.update);
router.delete('/:id', medicationController.delete);

module.exports = router;

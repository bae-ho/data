const db = require('../db');

exports.create = (req, res) => {
    const newMedication = req.body;
    const sql = 'INSERT INTO Medication (Name, Description, StockQuantity, Price) VALUES (?,?,?,?)';
    db.query(sql, [newMedication.Name, newMedication.Description, newMedication.StockQuantity, newMedication.Price], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(201).json({ message: 'Medication created!', id: result.insertId });
    });
};

exports.findAll = (req, res) => {
    const sql = 'SELECT * FROM Medication';
    db.query(sql, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json(results);
    });
};

exports.findById = (req, res) => {
    const id = req.params.id;
    const sql = 'SELECT * FROM Medication WHERE MedicationID = ?';
    db.query(sql, [id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json(result);
    });
};

exports.update = (req, res) => {
    const id = req.params.id;
    const updatedMedication = req.body;
    const sql = 'UPDATE Medication SET Name = ?, Description = ?, StockQuantity = ?, Price = ? WHERE MedicationID = ?';
    db.query(sql, [updatedMedication.Name, updatedMedication.Description, updatedMedication.StockQuantity, updatedMedication.Price, id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json({ message: 'Medication updated!' });
    });
};

exports.delete = (req, res) => {
    const id = req.params.id;
    const sql = 'DELETE FROM Medication WHERE MedicationID = ?';
    db.query(sql, [id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json({ message: 'Medication deleted!' });
    });
};

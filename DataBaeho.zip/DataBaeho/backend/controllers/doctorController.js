const db = require('../db');

exports.create = (req, res) => {
    const newDoctor = req.body;
    const sql = 'INSERT INTO Doctor (FirstName, LastName, Specialty, PhoneNumber, Email) VALUES (?,?,?,?,?)';
    db.query(sql, [newDoctor.FirstName, newDoctor.LastName, newDoctor.Specialty, newDoctor.PhoneNumber, newDoctor.Email], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(201).json({ message: 'Doctor created!', id: result.insertId });
    });
};

exports.findAll = (req, res) => {
    const sql = 'SELECT * FROM Doctor';
    db.query(sql, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json(results);
    });
};

exports.findById = (req, res) => {
    const id = req.params.id;
    const sql = 'SELECT * FROM Doctor WHERE DoctorID = ?';
    db.query(sql, [id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json(result);
    });
};

exports.update = (req, res) => {
    const id = req.params.id;
    const updatedDoctor = req.body;
    const sql = 'UPDATE Doctor SET FirstName = ?, LastName = ?, Specialty = ?, PhoneNumber = ?, Email = ? WHERE DoctorID = ?';
    db.query(sql, [updatedDoctor.FirstName, updatedDoctor.LastName, updatedDoctor.Specialty, updatedDoctor.PhoneNumber, updatedDoctor.Email, id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json({ message: 'Doctor updated!' });
    });
};

exports.delete = (req, res) => {
    const id = req.params.id;
    const sql = 'DELETE FROM Doctor WHERE DoctorID = ?';
    db.query(sql, [id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json({ message: 'Doctor deleted!' });
    });
};

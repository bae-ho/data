const db = require('../db');

exports.create = (req, res) => {
    const newAppointment = req.body;
    const sql = 'INSERT INTO Appointment (PatientID, DoctorID, AppointmentDate, AppointmentTime, Diagnosis, Treatment) VALUES (?,?,?,?,?,?)';
    db.query(sql, [newAppointment.PatientID, newAppointment.DoctorID, newAppointment.AppointmentDate, newAppointment.AppointmentTime, newAppointment.Diagnosis, newAppointment.Treatment], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(201).json({ message: 'Appointment created!', id: result.insertId });
    });
};

exports.findAll = (req, res) => {
    const sql = 'SELECT * FROM Appointment';
    db.query(sql, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json(results);
    });
};

exports.findById = (req, res) => {
    const id = req.params.id;
    const sql = 'SELECT * FROM Appointment WHERE AppointmentID = ?';
    db.query(sql, [id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json(result);
    });
};

exports.update = (req, res) => {
    const id = req.params.id;
    const updatedAppointment = req.body;
    const sql = 'UPDATE Appointment SET PatientID = ?, DoctorID = ?, AppointmentDate = ?, AppointmentTime = ?, Diagnosis = ?, Treatment = ? WHERE AppointmentID = ?';
    db.query(sql, [updatedAppointment.PatientID, updatedAppointment.DoctorID, updatedAppointment.AppointmentDate, updatedAppointment.AppointmentTime, updatedAppointment.Diagnosis, updatedAppointment.Treatment, id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json({ message: 'Appointment updated!' });
    });
};

exports.delete = (req, res) => {
    const id = req.params.id;
    const sql = 'DELETE FROM Appointment WHERE AppointmentID = ?';
    db.query(sql, [id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json({ message: 'Appointment deleted!' });
    });
};

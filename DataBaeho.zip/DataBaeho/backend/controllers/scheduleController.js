const db = require('../db');

exports.create = (req, res) => {
    const newSchedule = req.body;
    const sql = 'INSERT INTO Schedule (DoctorID, AvailableDate, AvailableTime) VALUES (?,?,?)';
    db.query(sql, [newSchedule.DoctorID, newSchedule.AvailableDate, newSchedule.AvailableTime], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(201).json({ message: 'Schedule created!', id: result.insertId });
    });
};

exports.findAll = (req, res) => {
    const sql = 'SELECT * FROM Schedule';
    db.query(sql, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json(results);
    });
};

exports.findById = (req, res) => {
    const id = req.params.id;
    const sql = 'SELECT * FROM Schedule WHERE ScheduleID = ?';
    db.query(sql, [id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json(result);
    });
};

exports.update = (req, res) => {
    const id = req.params.id;
    const updatedSchedule = req.body;
    const sql = 'UPDATE Schedule SET DoctorID = ?, AvailableDate = ?, AvailableTime = ? WHERE ScheduleID = ?';
    db.query(sql, [updatedSchedule.DoctorID, updatedSchedule.AvailableDate, updatedSchedule.AvailableTime, id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json({ message: 'Schedule updated!' });
    });
};

exports.delete = (req, res) => {
    const id = req.params.id;
    const sql = 'DELETE FROM Schedule WHERE ScheduleID = ?';
    db.query(sql, [id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json({ message: 'Schedule deleted!' });
    });
};

const db = require('../db');

exports.create = (req, res) => {
    const newPatient = req.body;
    const sql = 'INSERT INTO Patient (FirstName, LastName, DateOfBirth, Gender, Address, PhoneNumber, Email) VALUES (?,?,?,?,?,?,?)';
    db.query(sql, [newPatient.FirstName, newPatient.LastName, newPatient.DateOfBirth, newPatient.Gender, newPatient.Address, newPatient.PhoneNumber, newPatient.Email], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(201).json({ message: 'Patient created!', id: result.insertId });
    });
};

exports.findAll = (req, res) => {
    const sql = 'SELECT * FROM Patient';
    db.query(sql, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json(results);
    });
};

exports.findById = (req, res) => {
    const id = req.params.id;
    const sql = 'SELECT * FROM Patient WHERE PatientID = ?';
    db.query(sql, [id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json(result);
    });
};

exports.update = (req, res) => {
    const id = req.params.id;
    const updatedPatient = req.body;
    const sql = 'UPDATE Patient SET FirstName = ?, LastName = ?, DateOfBirth = ?, Gender = ?, Address = ?, PhoneNumber = ?, Email = ? WHERE PatientID = ?';
    db.query(sql, [updatedPatient.FirstName, updatedPatient.LastName, updatedPatient.DateOfBirth, updatedPatient.Gender, updatedPatient.Address, updatedPatient.PhoneNumber, updatedPatient.Email, id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json({ message: 'Patient updated!' });
    });
};

exports.delete = (req, res) => {
    const id = req.params.id;
    const sql = 'DELETE FROM Patient WHERE PatientID = ?';
    db.query(sql, [id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json({ message: 'Patient deleted!' });
    });
};

function loadPatients() {
    fetch('/patients')
        .then(response => response.json())
        .then(data => {
            const content = document.getElementById('patient-content');
            content.innerHTML = '<h2 class="text-xl font-bold mb-2">Patients</h2>';
            data.forEach(patient => {
                const div = document.createElement('div');
                div.innerHTML = `
                    <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
                        <p><strong>ID:</strong> ${patient.PatientID}</p>
                        <p><strong>FirstName:</strong> ${patient.FirstName}</p>
                        <p><strong>LastName:</strong> ${patient.LastName}</p>
                        <p><strong>DateOfBirth:</strong> ${patient.DateOfBirth}</p>
                        <p><strong>Gender:</strong> ${patient.Gender}</p>
                        <p><strong>Address:</strong> ${patient.Address}</p>
                        <p><strong>PhoneNumber:</strong> ${patient.PhoneNumber}</p>
                        <p><strong>Email:</strong> ${patient.Email}</p>
                        <button onclick="deletePatient(${patient.PatientID})" class="bg-red-500 text-white px-4 py-2 rounded">Delete</button>
                    </div>
                `;
                content.appendChild(div);
            });
        }).catch(error => console.error('Error loading patients:', error));
}

function addPatient() {
    const patient = {
        FirstName: document.getElementById('first-name').value,
        LastName: document.getElementById('last-name').value,
        DateOfBirth: document.getElementById('dob').value,
        Gender: document.getElementById('gender').value,
        Address: document.getElementById('address').value,
        PhoneNumber: document.getElementById('phone-number').value,
        Email: document.getElementById('email').value
    };

    fetch('/patients', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(patient)
    })
    .then(response => response.json())
    .then(data => {
        console.log(data.message);
        loadPatients(); // 추가 후 데이터 다시 로드
        document.getElementById('patient-form').reset(); // 폼 초기화
    })
    .catch(error => console.error('Error adding patient:', error));
}

function deletePatient(id) {
    fetch(`/patients/${id}`, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(data => {
        console.log(data.message);
        loadPatients(); // 삭제 후 데이터 다시 로드
    })
    .catch(error => console.error('Error deleting patient:', error));
}

function loadDoctors() {
    fetch('/doctors')
        .then(response => response.json())
        .then(data => {
            const content = document.getElementById('doctor-content');
            content.innerHTML = '<h2 class="text-xl font-bold mb-2">Doctors</h2>';
            data.forEach(doctor => {
                const div = document.createElement('div');
                div.innerHTML = `
                    <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
                        <p><strong>ID:</strong> ${doctor.DoctorID}</p>
                        <p><strong>FirstName:</strong> ${doctor.FirstName}</p>
                        <p><strong>LastName:</strong> ${doctor.LastName}</p>
                        <p><strong>Specialty:</strong> ${doctor.Specialty}</p>
                        <p><strong>PhoneNumber:</strong> ${doctor.PhoneNumber}</p>
                        <p><strong>Email:</strong> ${doctor.Email}</p>
                        <button onclick="deleteDoctor(${doctor.DoctorID})" class="bg-red-500 text-white px-4 py-2 rounded">Delete</button>
                    </div>
                `;
                content.appendChild(div);
            });
        }).catch(error => console.error('Error loading doctors:', error));
}

function addDoctor() {
    const doctor = {
        FirstName: document.getElementById('doctor-first-name').value,
        LastName: document.getElementById('doctor-last-name').value,
        Specialty: document.getElementById('doctor-specialty').value,
        PhoneNumber: document.getElementById('doctor-phone-number').value,
        Email: document.getElementById('doctor-email').value
    };

    fetch('/doctors', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(doctor)
    })
    .then(response => response.json())
    .then(data => {
        console.log(data.message);
        loadDoctors(); // 추가 후 데이터 다시 로드
        document.getElementById('doctor-form').reset(); // 폼 초기화
    })
    .catch(error => console.error('Error adding doctor:', error));
}

function deleteDoctor(id) {
    fetch(`/doctors/${id}`, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(data => {
        console.log(data.message);
        loadDoctors(); // 삭제 후 데이터 다시 로드
    })
    .catch(error => console.error('Error deleting doctor:', error));
}



function loadAppointments() {
    fetch('/appointments')
        .then(response => response.json())
        .then(data => {
            const content = document.getElementById('appointment-content');
            content.innerHTML = '<h2 class="text-xl font-bold mb-2">Appointments</h2>';
            data.forEach(appointment => {
                const div = document.createElement('div');
                div.innerHTML = `
                    <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
                        <p><strong>ID:</strong> ${appointment.AppointmentID}</p>
                        <p><strong>PatientID:</strong> ${appointment.PatientID}</p>
                        <p><strong>DoctorID:</strong> ${appointment.DoctorID}</p>
                        <p><strong>AppointmentDate:</strong> ${appointment.AppointmentDate}</p>
                        <p><strong>AppointmentTime:</strong> ${appointment.AppointmentTime}</p>
                        <p><strong>Diagnosis:</strong> ${appointment.Diagnosis}</p>
                        <p><strong>Treatment:</strong> ${appointment.Treatment}</p>
                        <button onclick="deleteAppointment(${appointment.AppointmentID})" class="bg-red-500 text-white px-4 py-2 rounded">Delete</button>
                    </div>
                `;
                content.appendChild(div);
            });
        }).catch(error => console.error('Error loading appointments:', error));
}

function addAppointment() {
    const appointment = {
        PatientID: document.getElementById('appointment-patient-id').value,
        DoctorID: document.getElementById('appointment-doctor-id').value,
        AppointmentDate: document.getElementById('appointment-date').value,
        AppointmentTime: document.getElementById('appointment-time').value,
        Diagnosis: document.getElementById('appointment-diagnosis').value,
        Treatment: document.getElementById('appointment-treatment').value
    };

    fetch('/appointments', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(appointment)
    })
    .then(response => response.json())
    .then(data => {
        console.log(data.message);
        loadAppointments(); // 추가 후 데이터 다시 로드
        document.getElementById('appointment-form').reset(); // 폼 초기화
    })
    .catch(error => console.error('Error adding appointment:', error));
}

function deleteAppointment(id) {
    fetch(`/appointments/${id}`, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(data => {
        console.log(data.message);
        loadAppointments(); // 삭제 후 데이터 다시 로드
    })
    .catch(error => console.error('Error deleting appointment:', error));
}


function loadSchedules() {
    fetch('/schedules')
        .then(response => response.json())
        .then(data => {
            const content = document.getElementById('schedule-content');
            content.innerHTML = '<h2 class="text-xl font-bold mb-2">Schedules</h2>';
            data.forEach(schedule => {
                const div = document.createElement('div');
                div.innerHTML = `
                    <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
                        <p><strong>ID:</strong> ${schedule.ScheduleID}</p>
                        <p><strong>DoctorID:</strong> ${schedule.DoctorID}</p>
                        <p><strong>AvailableDate:</strong> ${schedule.AvailableDate}</p>
                        <p><strong>AvailableTime:</strong> ${schedule.AvailableTime}</p>
                        <button onclick="deleteSchedule(${schedule.ScheduleID})" class="bg-red-500 text-white px-4 py-2 rounded">Delete</button>
                    </div>
                `;
                content.appendChild(div);
            });
        }).catch(error => console.error('Error loading schedules:', error));
}

function addSchedule() {
    const schedule = {
        DoctorID: document.getElementById('schedule-doctor-id').value,
        AvailableDate: document.getElementById('schedule-date').value,
        AvailableTime: document.getElementById('schedule-time').value
    };

    fetch('/schedules', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(schedule)
    })
    .then(response => response.json())
    .then(data => {
        console.log(data.message);
        loadSchedules(); // 추가 후 데이터 다시 로드
        document.getElementById('schedule-form').reset(); // 폼 초기화
    })
    .catch(error => console.error('Error adding schedule:', error));
}

function deleteSchedule(id) {
    fetch(`/schedules/${id}`, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(data => {
        console.log(data.message);
        loadSchedules(); // 삭제 후 데이터 다시 로드
    })
    .catch(error => console.error('Error deleting schedule:', error));
}


function loadMedications() {
    fetch('/medications')
        .then(response => response.json())
        .then(data => {
            const content = document.getElementById('medication-content');
            content.innerHTML = '<h2 class="text-xl font-bold mb-2">Medications</h2>';
            data.forEach(medication => {
                const div = document.createElement('div');
                div.innerHTML = `
                    <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
                        <p><strong>ID:</strong> ${medication.MedicationID}</p>
                        <p><strong>Name:</strong> ${medication.Name}</p>
                        <p><strong>Description:</strong> ${medication.Description}</p>
                        <p><strong>Stock Quantity:</strong> ${medication.StockQuantity}</p>
                        <p><strong>Price:</strong> ${medication.Price}</p>
                        <button onclick="deleteMedication(${medication.MedicationID})" class="bg-red-500 text-white px-4 py-2 rounded">Delete</button>
                    </div>
                `;
                content.appendChild(div);
            });
        }).catch(error => console.error('Error loading medications:', error));
}

function addMedication() {
    const medication = {
        Name: document.getElementById('medication-name').value,
        Description: document.getElementById('medication-description').value,
        StockQuantity: document.getElementById('medication-stock').value,
        Price: document.getElementById('medication-price').value
    };

    fetch('/medications', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(medication)
    })
    .then(response => response.json())
    .then(data => {
        console.log(data.message);
        loadMedications(); // 추가 후 데이터 다시 로드
        document.getElementById('medication-form').reset(); // 폼 초기화
    })
    .catch(error => console.error('Error adding medication:', error));
}

function deleteMedication(id) {
    fetch(`/medications/${id}`, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(data => {
        console.log(data.message);
        loadMedications(); // 삭제 후 데이터 다시 로드
    })
    .catch(error => console.error('Error deleting medication:', error));
}

document.addEventListener('DOMContentLoaded', () => {
    loadMedications();
});

